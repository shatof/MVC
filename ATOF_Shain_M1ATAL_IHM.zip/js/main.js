let model = new Model();
let controler = new Controler(model, 'index');
